# Review helper for Common Voice Sentence Collector

## How to use
- Copy and excute [review helper script](https://github.com/irvin/review-helper-for-common-voice-sentence-collector/blob/master/common_voice_review_helper.js) from console in browser inspector,
- or installed through [Firefox addon](https://addons.mozilla.org/firefox/addon/cv-review-helper/) (still in reviewing on AMO).

The script will default downvote any sentences with downvote from others, and upvote all remands.

## Special rules

- Downvote any sentences with space in zh-TW / zh-HK
