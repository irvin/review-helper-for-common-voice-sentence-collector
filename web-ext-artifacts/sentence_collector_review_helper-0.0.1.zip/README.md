# Review helper for Common Voice Sentence Collector

- Excute on console in inspector.
- Default downvote any sentences with downvote from others, and upvote all remands.

## specific criteria

- downvote any sentences with space in zh-TW / zh-HK
